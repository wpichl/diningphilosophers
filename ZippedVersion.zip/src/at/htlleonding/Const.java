package at.htlleonding;

public class Const {
    public static final String TransactionMsg = "transaction";

    public static final short NumberOfTransactions = 5;

    public static final boolean StaleMatePossible = false;
}
